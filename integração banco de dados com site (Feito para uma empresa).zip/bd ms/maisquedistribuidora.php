<?php

$servername = "localhost"; // nome do servidor do banco de dados
$username = "root"; // nome de usuário do banco de dados
$password = ""; // senha do banco de dados
$dbname = "maisquedistribuidora"; // nome do banco de dados

// Criar conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar a conexão
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

// Linkar banco de dados
$nome = $_POST['nome'];
$email = $_POST['email'];
$telefone = $_POST['telefone'];

$sql = "INSERT INTO listadeespera (nome, telefone, email) VALUES ('$nome', '$telefone', '$email')";
if ($conn->query($sql) === TRUE) {
    echo "Dados inseridos com sucesso.";
} else {
    echo "Erro ao inserir os dados: " . $conn->error;
}

// Fechar a conexão
$conn->close();





?>
