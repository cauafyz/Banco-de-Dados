<?php
      if (!empty($_POST['nome']) && !empty($_POST['email']) && !empty($_POST['telefone'])) {
        $nome = $_POST['nome'];
        $email = $_POST['email'];
        $telefone = $_POST['telefone'];

        echo "Nome: " . $nome . "<br>";
        echo "Email: " . $email . "<br>";
        echo "Telefone: " . $telefone . "<br>";
      }
      ?>
      


<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Nathalia Guile</title>

  <link rel="stylesheet" href="style.css">

  <!--Fontes-->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Montserrat&display=swap" rel="stylesheet">
  <!--Fontes-->

</head>
<body>
    <main>
      <h1>Lista De Espera</h1>
      <p>Nome DO courso</p>

      

      <form action="maisquedistribuidora.php" method="post">
        <label for="name">
          <span>Nome Completo</span>
          <input type="text" id="name" name="nome">
        </label>
        <label for="email">
          <span>E-mail</span>
          <input type="email" id="email" name="email">
        </label>
        <label for="telefone">
          <span>Telefone</span>
          <input type="tel" id="telefone" name="telefone">
        </label>

        <input type="submit" value="Enviar">
      </form>

      <form action="apagar_dados.php" method="post">
        <input type="submit" name="apagar" value="Apagar Dados">
      </form>

      <div class="social-media">
        <a href="#">
          <img src="Icons/facebook.png" alt="Facebook">
        </a>
        <a href="#">
          <img src="Icons/logotipo-do-instagram.png" alt="Instagram">
        </a>
        <a href="#">
          <img src="Icons/tiktok.png" alt="Tiktok">
        </a>
      </div>
    </main>


        <!--EC Publicidade-->

        <div class="ec">
          <h2>Produzido por EC Publicidade</h2>
          <p>Clara Catarin</p>
      </div>

  <!--EC Publicidade-->
</body>
</html>
