
<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "maisquedistribuidora";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

// Executar a instrução SQL DELETE
$sql = "DELETE FROM listadeespera";
if ($conn->query($sql) === TRUE) {
    echo "Dados apagados com sucesso.";
} else {
    echo "Erro ao apagar os dados: " . $conn->error;
}

$conn->close();

?>